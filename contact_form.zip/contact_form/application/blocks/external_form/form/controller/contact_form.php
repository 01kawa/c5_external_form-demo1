<?php
namespace Application\Block\ExternalForm\Form\Controller;

use Concrete\Core\Controller\AbstractController;
use Concrete\Core\Page\Theme\Theme;
use Core;
use UserInfo;
use Concrete\Core\Page\PageList;

class ContactForm extends AbstractController
{
    public function action_send_mail($bID = false)
    {
        if ($this->bID == $bID) {
      // validation/form ヘルパーを呼び出し
        $val = Core::make('helper/validation/form');
        $val->setData($this->post());

      // validationバリデーション設定
        $val->addRequired('name', '名前を入力してください。');
        $val->addRequired('tel', '電話番号を入力してください。');
        $val->addRequiredEmail('email', '有効なメールアドレスを入力してください。');

      // バリデーション実行と結果の取得
        if (!$val->test()) {
          // エラーあり
          $errorArray = $val->getError()->getList(); // エラーメッセージの取得
          $this->set('error', $errorArray); // $error にエラーメッセージを格納
        } else {
          // エラーなし
          $mh = Core::make('helper/mail'); // メールヘルパー呼び出し
          // メールヘッダーを設定
          $mh->to($this->post('email')); //登録者への自動返信
          $mh->bcc('bcc@example.com'); //メール管理者へbcc送信
          $mh->from('from@example.com', '送信者名'); //メール送信元
          // メールの内容を取得
          $mh->addParameter('name', $this->post('name'));
          $mh->addParameter('tel', $this->post('tel'));
          $mh->addParameter('add', $this->post('add'));
          $mh->addParameter('email', $this->post('email'));
          $mh->addParameter('reason', $this->post('reason'));
          // メール送信
          $mh->load('contactthanks'); // メールテンプレートの読み込み
          $mh->sendMail(); // メール送信
          $this->set('response', true); // ステータスを設定
          return true; 
        }
        }
    }
}
