<?php
defined('C5_EXECUTE') or die("Access Denied.");
$form = Core::make('helper/form');// フォームヘルパー読み込み
$c = Page::getCurrentPage();// ページリスト読み込み
?>

<?php
if (isset($response)) {
  // コントローラー処理完了後の処理（サンクスメッセージなど）
    ?>
  <div id="thanks">
  <h3>お問い合わせが完了いたしました</h3>
  <p>お問い合わせありがとうございます。<br>自動返信メールを送信いたしました。</p>
  </div>
<?php 
} else {
  // フォーム表示（初回入力・再入力共通）
  if(isset($error)) {
    // エラー表示
?>
    <div class="has-error">
      <p class="help-block">入力内容に誤りがあります。</p>
      <?php
            foreach($error as $errmsg) {
              echo '<p>'.$errmsg.'</p>';
            }
      ?>
    </div>
<?php
}
?>
    <form class="form-horizontal" method="post" action="<?php echo $view->action('send_mail')?>">
<?php
      echo '<div class="form-group">';

      // テキスト
      echo '<div class="form-group">';
      echo $form->label('name', 'お名前', array('class' => 'col-sm-3'));
      echo '<div class="col-sm-9">'.$form->text('name', array('placeholder' => '必須項目')).'</div>';
      echo '</div>';
      // TEL
      echo '<div class="form-group">';
      echo $form->label('tel', '電話番号', array('class' => 'col-sm-3'));
      echo '<div class="col-sm-9">'.$form->telephone('tel', array('placeholder' => '必須項目')).'<small>日中ご連絡可能なお電話番号を入力ください。（ハイフンは不要です）</small></div>';
      echo '</div>';
      // テキストエリア
      echo '<div class="form-group">';
      echo $form->label('add', 'ご住所', array('class' => 'col-sm-3'));
      echo '<div class="col-sm-9">'.$form->textarea('add', '〒', array('rows' => 5)).'</div>';
      echo '</div>';
      // メールアドレス
      echo '<div class="form-group">';
      echo $form->label('email', 'メールアドレス', array('class' => 'col-sm-3'));
      echo '<div class="col-sm-9">'.$form->email('email', array('placeholder' => '必須項目')).'</div>';
      echo '</div>';
      // テキストエリア
      echo '<div class="form-group">';
      echo $form->label('reason', 'メッセージ', array('class' => 'col-sm-3'));
      echo '<div class="col-sm-9">'.$form->textarea('reason', '', array('rows' => 5)).'</div>';
      echo '</div>';
      // 送信ボタン
      echo '<div class="form-group">';
      echo '<div class="col-sm-offset-3 col-sm-9">'.$form->submit('submit', '送信', array('class' => 'btn-primary')).'</div>';
      echo '</div>';
?>
   </form>
<?php
}